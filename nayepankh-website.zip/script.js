
  // ---------- NAV / ROUTER ----------
  const pages = document.querySelectorAll('.page');
  const navBtns = document.querySelectorAll('[data-page]');
  function goPage(name){
    pages.forEach(p => p.classList.toggle('active', p.id === 'page-'+name));
    document.querySelectorAll('.navlinks button').forEach(b => b.classList.toggle('active', b.dataset.page === name));
    document.getElementById('mobileMenu').classList.remove('open');
    document.getElementById('burger').classList.remove('open');
    window.scrollTo({top:0, behavior:'instant' in window ? 'instant':'auto'});
    history.replaceState(null,'','#'+name);
    runReveal();
  }
  navBtns.forEach(b => b.addEventListener('click', () => goPage(b.dataset.page)));
  window.addEventListener('DOMContentLoaded', () => {
    const initial = location.hash.replace('#','') || 'home';
    goPage(['home','about','programs','involve','contact'].includes(initial) ? initial : 'home');
  });

  // ---------- HEADER SCROLL STATE ----------
  const header = document.getElementById('siteHeader');
  document.addEventListener('scroll', () => header.classList.toggle('scrolled', window.scrollY > 30));

  // ---------- MOBILE MENU ----------
  const burger = document.getElementById('burger');
  const mobileMenu = document.getElementById('mobileMenu');
  burger.addEventListener('click', () => {
    burger.classList.toggle('open');
    mobileMenu.classList.toggle('open');
  });

  // ---------- REVEAL ON SCROLL ----------
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => { if(e.isIntersecting) e.target.classList.add('in'); });
  }, {threshold:0.15});
  function runReveal(){
    document.querySelectorAll('.reveal').forEach(el => io.observe(el));
  }
  // safety net: ensure nothing stays invisible if IO ever misses an element
  setTimeout(() => document.querySelectorAll('.reveal').forEach(el => el.classList.add('in')), 2500);

  const counters = document.querySelectorAll('[data-count]');
  let countersDone = false;
  function formatCount(n, suffix, nogroup){
    let s = nogroup ? String(n) : n.toLocaleString('en-IN');
    return s + (suffix || '');
  }
  function triggerCounters(){
    if(countersDone) return;
    countersDone = true;
    counters.forEach(c => {
      const target = parseInt(c.dataset.count, 10);
      const suffix = c.dataset.suffix || '';
      const nogroup = c.dataset.nogroup;
      const dur = 1400;
      const start = performance.now();
      function step(t){
        const p = Math.min(1, (t-start)/dur);
        const eased = 1 - Math.pow(1-p, 3);
        c.textContent = formatCount(Math.floor(eased*target), suffix, nogroup);
        if(p<1) requestAnimationFrame(step); else c.textContent = formatCount(target, suffix, nogroup);
      }
      requestAnimationFrame(step);
    });
  }
  const countIO = new IntersectionObserver(entries => {
    entries.forEach(e => { if(e.isIntersecting) triggerCounters(); });
  }, {threshold:0.4});
  if(counters.length) countIO.observe(counters[0].closest('.hero-stat-strip'));
  setTimeout(triggerCounters, 3000);

  // ---------- WING SVG (signature element) ----------
  (function(){
    const g = document.getElementById('featherGroup');
    const N = 9;
    const cx = 70, cy = 380;
    for(let i=0;i<N;i++){
      const t = i/(N-1);
      const angle = -85 + t*95; // fan from bottom to upper-right
      const len = 230 - i*9;
      const wid = 46 - i*2.6;
      const hue = i%2===0 ? '#F6A53D' : '#E2572B';
      const path = document.createElementNS('http://www.w3.org/2000/svg','path');
      const d = `M0,0 C ${len*0.25},${-wid} ${len*0.75},${-wid*0.9} ${len},0 C ${len*0.75},${wid*0.9} ${len*0.25},${wid} 0,0 Z`;
      path.setAttribute('d', d);
      path.setAttribute('fill', hue);
      path.setAttribute('opacity', (0.55 + t*0.45).toFixed(2));
      path.classList.add('wing-feather');
      path.style.transform = `translate(${cx}px,${cy}px) rotate(${angle}deg) scale(0,1)`;
      path.style.transformOrigin = '0px 0px';
      path.style.transition = `transform 0.7s cubic-bezier(.2,.8,.2,1) ${i*70}ms`;
      g.appendChild(path);
      requestAnimationFrame(()=>{
        setTimeout(()=>{ path.style.transform = `translate(${cx}px,${cy}px) rotate(${angle}deg) scale(1,1)`; }, 50);
      });
      // gentle ambient sway after entrance
      setTimeout(()=>{
        path.style.transition = 'transform 3.2s ease-in-out';
        let swing = false;
        setInterval(()=>{
          swing = !swing;
          const a2 = angle + (swing? 2.2 : -2.2);
          path.style.transform = `translate(${cx}px,${cy}px) rotate(${a2}deg) scale(1,1)`;
        }, 3200);
      }, 900 + i*70);
    }
  })();

  // ---------- DONATION CALCULATOR ----------
  const donAmount = document.getElementById('donAmount');
  const donSlider = document.getElementById('donSlider');
  const rDonate = document.getElementById('rDonate');
  const rRelief = document.getElementById('rRelief');
  const rCost = document.getElementById('rCost');
  function inr(n){ return '₹' + Math.round(n).toLocaleString('en-IN'); }
  function updateCalc(val){
    val = Math.max(0, val||0);
    rDonate.textContent = inr(val);
    rRelief.textContent = inr(val*0.5);
    rCost.textContent = inr(val*0.5);
  }
  donAmount.addEventListener('input', () => { donSlider.value = Math.min(donAmount.value,20000); updateCalc(parseFloat(donAmount.value)); });
  donSlider.addEventListener('input', () => { donAmount.value = donSlider.value; updateCalc(parseFloat(donSlider.value)); });
  updateCalc(2000);

  // ---------- CONTACT FORM ----------
  const form = document.getElementById('contactForm');
  const formMsg = document.getElementById('formMsg');
  form.addEventListener('submit', e => {
    e.preventDefault();
    formMsg.classList.add('show');
    form.querySelector('button[type=submit]').setAttribute('disabled','disabled');
    form.querySelector('button[type=submit]').textContent = 'Message sent ✓';
  });

  runReveal();
